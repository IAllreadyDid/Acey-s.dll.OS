BerkFind 2.1 [free trial] for Win32 - http://www.pc-tools.net/
Copyright (C) 1999-2002, Jem Berkes <jberkes@pc-tools.net>

Release date: 2002-09-28
Description: BerkFind is a win32 command line (console) file finder.
             It can search for files by name as well as contents,
             doing a case sensitive or insensitive search. Output is
             easy to read, and found files are grouped by directory.

Executable compressed with UPX -- http://upx.sourceforge.net/

===========================
License & Conditions of Use
===========================
DISCLAIMER:
This software is provided "as is" and without any warranties as to
performance, merchantability, fitness for a particular purpose, or
any other warranties whether expressed or implied. The entire risk
as to the results and performance of the software is assumed by you.
The author shall not have any liability to you or any other person
or entity for any damages whatsoever, including, but not limited to,
loss of revenue or profit, lost or damaged data or other. The author
is also not responsible for claims by a third party.

LICENSE:
The free trial version of BerkFind may be used indefinitely for
educational and non-commercial use. Commercial/business users may
also use the free trial version for a limited period, but are asked
to purchase the full version if they plan to continue using the
software.

CONDITIONS:
You may distribute the free trial version of BerkFind in its original,
unmodified form only. You are specifically prohibited from charging,
or requesting donations, for any such copies, however made; and from
distributing the software and/or documentation with other products
(commercial or otherwise) without prior written permission from the
author.

You may not modify the software or documentation in any way. You may
not translate, reverse engineer, decompile, or disassemble the
software.

=================================
Registering / Purchasing BerkFind
=================================
This free trial version is missing some of the features that are only
available in the full version. These additional command line switches,
available only to those who register, are explained below:

/D	Asks whether to delete found files
	You can answer No, Yes, or All ('yes' for all files)

/Y	Answers 'yes' to all delete prompts, used with /D

/J	Jump to found files. For each matching file, asks you whether
	you want to "Open" the found file, "Explore" in its directory,
	or do "Nothing".
	The "Open" option will launch the file using the registered
	windows application for that file type, if any exists. It's
	equivalent to typing "start filename" from the command prompt.
	The "Explore" option opens the default windows directory
	browser in the directory where the file was found.
	These two options use the windows graphical user interface,
	so if you are at the command prompt the BerkFind session will
	be put in the background.

PRICING: BerkFind costs USD 25 and can be ordered online from
PC-Tools.Net. You can order from any country, and pay by credit card
using the secure online form. Software is automatically delivered by
e-mail and the entire registration process is fast and easy. Please
visit:

http://www.pc-tools.net/order/

Our orders go through ShareIt's online software registration system.
Once the funds have been transferred (by credit card, cheque, or wire
transfer) ShareIt will send you a copy of the registered software.

If you have any questions about this product, please contact:
jberkes@pc-tools.net

BENEFITS: Registered users not only receive a superior version of
the program, but also enjoy free technical support by e-mail as well
as free upgrades for 3 years. If you use the software often, please
consider purchasing a copy of BerkFind.

PRIVACY: I have never sold, and will never sell in the future, your
private contact information. You will not receive spam resulting
from your software purchase. I also never see your credit card number
since the orders are handled through ShareIt's automated, secure
system.

==================
USING THE SOFTWARE
==================
BerkFind is a command line (console) application for win32. It's not
a DOS program, since it requires a 32-bit Windows environment in order
to run. BerkFind has been tested under Win9x/ME/NT/2000/XP.

You must copy the berkfind.exe file to a location in your PATH (for
example, c:\windows) so that you can use it just by typing 'berkfind'.

The command line syntax is:
berkfind [startpath] filespec [/C text] [/I text] [/P]

If startpath is omitted, searching will begin in the root directory of
the current drive. If a startpath is specified, the search will only
involve that directory and its subdirectories.

/C matches files that contain the case sensitive search text
/I matches files that contain the case insensitive search text
/P pauses the output to show one screen at a time

Examples of usage:
berkfind *.txt /p
berkfind c:\ *.doc /i budget

The registered version supports these further switches:
/D asks whether to delete found files
/Y answers 'yes' to all delete prompts (dangerous!)
/J asks whether to Open found files/programs or Explore in directories

In the registered version you can add /j to the last example to Open
matching files using the default application (e.g. Microsoft Word), or
browse that directory in Explorer. If you are interested in purchasing
a copy of BerkFind, please see the "Registering / Purchasing BerkFind"
section above. The full version costs USD 25.
