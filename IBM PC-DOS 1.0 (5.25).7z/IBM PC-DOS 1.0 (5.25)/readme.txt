IBM PC-DOS 1.00
Complete.

CONTENTS:
PCDOS100.IMG - The image itself. It won't be read by PCem, WinImage or Bochs (bochs needs a config change).

FILES.ZIP - I supply the files from the image so you can examine them without doing too much stuff.