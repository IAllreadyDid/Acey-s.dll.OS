JBMail 3.0		2002-02-25
Copyright (C) 1999-2002 Jem E. Berkes <jb2002@pc9.org>
http://www.pc-tools.net/

Distributed with NSIS installer -- http://www.nullsoft.com/free/nsis/
Executables are compressed with UPX -- http://upx.sourceforge.net/

BEFORE USING THE SOFTWARE IN THIS PACKAGE, YOU MUST READ AND AGREE
TO THE TERMS LISTED IN THE MANUAL/DOCUMENTATION (jbm-help.htm)
Section: 0. License & Conditions of Use

This free trial version has full functionality except that only one
profile is retained when you exit. To purchase JBMail Plus (the full
version, which retains all profiles) please visit:
http://www.pc-tools.net/order/

In this new version, the full documentation is provided in HTML
format. The manual is approximately 20 pages when printed out. Using
the "Help" buttons in JBMail, you can jump to appropriate places in
the manual.

--> Start JBMail, and select "Quick start guide" from the Help menu

Version 3.0 is a major release with a large number of improvements.
Listed below are some of the major changes, but see section 8.2
(Version history) in the manual for a full list.

* Much faster than earlier versions, especially during message
downloading and attachment decoding

* Ability to send UUencoded attachments (and no temporary files are
created)

* New address book system which supports multiple address books

* Recently used addresses list for quick access to frequently used
e-mail addresses

* Improved message viewer and composer. Also no longer has message
length limits.

* Address handling re-written. The message viewer and composer now
properly handle multiple recipients.

* Better junk mail (spam) detection with new filters and an extremely
handy blacklist option.

* New command line switches can poll all mailboxes upon startup and
minimize the JBMail window.

* SMTP module re-written to properly handle ESMTP and authentication.
Now also capable of automatic copies to self via BCC.
