IBM DOS 1.10 (5�) (160kb)
---
.IMG format.
Will NOT be read by WinImage as uses non-standard boot sector.
Needs special flag on Bochs.
Should be able to be read by DOS and most BIOSes.