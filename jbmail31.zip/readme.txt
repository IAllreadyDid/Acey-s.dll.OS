JBMail 3.1		2002-07-14
Copyright (C) 1999-2002 Jem E. Berkes <jb2002@pc9.org>
http://www.pc-tools.net/

Executable compressed with UPX -- http://upx.sourceforge.net/

BEFORE USING THE SOFTWARE IN THIS PACKAGE, YOU MUST READ AND AGREE
TO THE TERMS LISTED IN THE MANUAL/DOCUMENTATION (jbm-help.htm)
Section: 0. License & Conditions of Use

This free trial version of JBMail never expires or nags for
registration. The limitations are that: (1) it can only save one
profile to disk, and (2) message flags (read, replied to states)
are not retained between sessions. In all other respects the free
trial version is identical to the full version.

The full version (JBMail Plus) can save multiple profiles to disk,
without limit, and retains all message flags/states in all profiles.
This makes JBMail much more convenient for frequent use since you
can painlessly access multiple mail accounts and see at a glance
which messages you have already read and replied to.

PRICING: JBMail Plus costs USD 35.00 and can be ordered online from
PC-Tools.Net. You can order from any country, and pay by credit card
using the secure online form. Software is automatically delivered by
e-mail and the entire registration process is fast and easy. Please
visit:

http://www.pc-tools.net/order/

BENEFITS: Registered users not only receive a superior version of
the program, but also enjoy free technical support by e-mail as well
as free upgrades for 3 years. If you use the software often, please
consider purchasing a copy of JBMail Plus. This software can not
exist without your support.

PRIVACY: I have never sold, and will never sell in the future, your
private contact information. You will not receive spam resulting
from your JBMail purchase. I also never see your credit card number
since the orders are handled through ShareIt's automated, secure
system.
