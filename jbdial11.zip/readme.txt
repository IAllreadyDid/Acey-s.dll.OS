JB-Dialer 1.1
Copyright (C) 1999-2000 Jem E. Berkes

http://www.pc-tools.net/

JB-Dialer lets you use your computer to automatically dial a phone
number. JB-Dialer does not use the modem, like most diallers, but
rather plays DTMF (touch-tone) frequencies through your speakers.
Just hold your phone set near your speakers, and have the program
dial the number for you. JB-Dialer acts as a convenient "speed-dial"
with an alphabetically-sorted phonebook.

JB-Dialer is also handy for remote DTMF programming. The length of
each tone is 150 ms, followed by a 50 ms break.

Requires: Sound card, speakers.

What's new in version 1.2:
* Slightly longer tones
* Supports up to 512 character dialstrings
* Now supports DTMF tones A through D

This is a FREE TRIAL VERSION. It will not expire after a certain date
or number of uses, and it does not contain annoying pop-up 'nags'.
The only limitation is that it will load a maximum of 20 entries from
the phone book. The full version can load an unlimited number of
entries from the phone book.

If you like the software, please purchase the full version:
- Support the author's hard work
- Get a more powerful version
- Get free updates of the software by e-mail

JB-Dialer costs only $15 US. You can order it online via a secure
online order form, or send in your order by fax or phone. Please see
instructions at:

http://www.pc-tools.net/order/

Please e-mail berkes@post.com if you have any questions.

==========
TO INSTALL
==========

Unzip all the files to a directory.

To add an icon to your desktop:
(1) Right-click on the desktop
(2) Select New, then Shortcut
(3) Type in the location, e.g. C:\JBDIALER\JBDIALER
(4) Enter shortcut name (JB-Dialer) then click Finish

To add an icon to your Start Menu:
(A) Right-click on your Start button, and select Open
(B) Navigate to the desired level (e.g. Programs/Accessories)
(C) Right-click on a blank spot in the folder
(D) Follow steps 2 thru 4 above

JB-Dialer consists of the following files. They must all be in the
same directory:

jbdialer.exe	(program itself)
numbers.txt	(phone book)
readme.txt	(this document)
num_0.wav	(touch-tones for numbers 0 thru 9)
... num_9.wav
sym_ast.wav	(touch-tone for asterisk)
sym_pnd.wav	(touch-tone for pound)
sym_a.wav	(touch-tones for A through D)
sym_b.wav
sym_c.wav
sym_d.wav


======
TO USE
======

Run the program.
Select desired phonebook entry, or type in the number to dial.
Hold your phone receiver up to your speaker.
Press the "Dial" button.

============
TO UNINSTALL
============

Because JB-Dialer does not create any registry settings or copy any
DLLs onto your system, it is very easy to uninstall. Just delete
the directory containing all the JB-Dialer files, then delete the
icon. (Right-click on Start button, then click Open to be able to
edit your Start menu).
