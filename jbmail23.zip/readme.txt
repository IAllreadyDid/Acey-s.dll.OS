JBMail 2.3 (FREE TRIAL VERSION)
An e-mail client and tool for Windows 95/98/ME/NT/2000+
Release date: 2001-07-02
Copyright (C) 1999-2001 Jem E. Berkes <jberkes@pc-tools.net>
http://www.pc-tools.net/
===============================================
AD-FREE, NAG-FREE trialware that NEVER EXPIRES!
===============================================

Note: jbmail.exe is now compressed with Markus F.X.J. Oberhumer's UPX
compression. http://upx.sourceforge.net

------------------------------
CONTENTS
--------
1. INTRODUCTION
2. LICENSE
3. INSTALLATION
4. WHY REGISTER? JBMAIL PLUS
5. CHANGELOG (VERSION HISTORY)


------------------------------
1. INTRODUCTION

JBMail is a unique Windows mail client/tool because it is designed
primarily to be portable (not dependent on local installation) and
flexible. It gives quick header based "unobtrusive" access to multiple
mailboxes and does not store messages, folder data and registry
settings locally. Access is focused on mail headers, so message bodies
aren't downloaded unless you ask for them. You can delete large volumes
of mail almost instantly (great for attachments and junk mail). The
entire program consists of a single small EXE file which can be easily
carried on a floppy disk or installed on a public/office workstation.
JBMail can also now act as a mail watcher, periodically checking
mailboxes and notifying you of new mail through a tray icon. And JBMail
doesn't interfere with your main e-mail client (does not automatically
delete mail from the server) rather, it acts as a speedy mail reader
or mailbox cleaning tool for times when normal access isn't available
or appropriate (e.g. while travelling, for checking colleagues' mail
accounts, for dealing with large volumes of mail...)

------------------------------
2. LICENSE

The free trial version of JBMail may be used indefinitely for
educational and non-commercial use. Commercial/business users may also
use the free trial version for a limited period, but are asked to
purchase JBMail Plus if they plan to continue using the software.
Software registration comes with free upgrades and technical support.
(See Section 4, below).

------------------------------
3. INSTALLATION

Just unzip jbmail.exe and jbmail.hlp to a directory, and run the
executable. JBMail is completely portable so you can even carry it
around on a floppy disk (does not write to the registry). Please see
the help file jbmail.hlp for complete documentation!

------------------------------
4. WHY REGISTER? JBMAIL PLUS

This free version never expires. However, if you use the software
frequently you may benefit from an added feature in JBMail Plus: the
full version can save profiles to disk. This also makes the master
passphrase feature possible.

JBMail Plus costs $35 US per license, and comes with technical support
and free upgrades for 3 years. Volume discounts are negotiable. Orders
can be placed online and you can pay by credit card if you wish. Visit
http://www.pc-tools.net/order/

------------------------------
5. CHANGELOG (VERSION HISTORY)

Version 2.3 (July 2, 2001)
- Partial mode now displays most RECENT 'x' messages
- Resized composer window to fit 640x480 screens
- Added master passphrase which can restrict access to all profiles
- Memory and processor usage reduced; uses VERY little resources
- 'Autosort newest to oldest' can also be done from inbox File menu
- Changed 'autosort by date' to 'autosort newest to oldest'
- Added BCC (blind CC) option to composer
- Added minimize button to message viewer and composer
- Added tray icon which notifies you of new mail (used by Mailman)
- Added 'Mailman', which automatically polls mailboxes at intervals
- Added 'enter only if mailbox modified' option
- Added 'poll all' button to Setup window
- Program is now much more efficient with disk access
- Re-wrote profile code; much cleaner and more flexible
- Displays a paper clip beside multipart messages
- Improved error handling in case POP3 server misbehaves
- Added 'autosave profile' option (saves profile when you connect)
- Added support for APOP (secure) logins
- Current profile stays on screen when you use Save / Update
- Now fills in {No subject} for messages in inbox with blank subjects
- Replies work correctly now, if full headers were enabled
- You can now use the Enter key to view messages in the inbox
- Switch between View or Preview for the Enter key in the Options menu
- Fixed a message downloading bug
- Tab key now correctly indents in message composer
- Added 200 line limit for reply quoting (win9x memory issue)
- Improved handling for cases in which attachment has full path
- Other minor changes

Version 2.2 (December 2000)
- Fixed a uudecoding bug
- Fixed an attachment filename extension bug for Win9x systems
- Reply to mail feature added
- "Message" menu removed (redundant)
- For nicer display, message viewer now hides attachment text
- SMTP support added (Use File/Compose e-mail)
- SMTP settings can be found under the "Options" tab
- Main tab is now the "Connect" tab
- Settings tab is now the "Options" tab
- Allows an IP address to be used for the server name, bypassing DNS
- Fixed some potential buffer overflows
- Now displays a status message while decoding and saving attachments
- Improved attachment-finding algorithm

Version 2.1 (August 2000)
- You can now poll a mailbox (quickly check the amount of mail waiting)
- New option to turn off header parsing for truly raw access
- Redesign of initial setup screen
- "Shortened headers" now look much nicer
- Long message headers are scanned much more quickly
- Fixed bug that caused hangs when loading poorly formatted headers
- More efficient memory usage when loading very large messages
- Fixed bug that occurred when changing selections during a delete
- Now always exits to Connection screen
- No more maximum message limit! Can load as many as memory allows
- Improved date fixing (for mailers that are not Y2K compatible)
- Added "Autosort by date" as a profile option
- Many other minor changes made

Version 2.0 (April 2000)
- Attachment finding algorithm improved
- Completely new help file and context sensitive help
- Can save settings between sessions (use Save under Options menu)
- Column titles reflect to show sort state (+ascending or -descending)
- New Advanced settings tab in opening screen
- Now disconnects from POP3 server before displaying "No mail" message
- Optional partial mailbox access: list only x messages
- Purge mailbox option: quickly clear all messages
- Free and registered version both access INI file in local directory
- Capable of flexible "guilty until proven innocent" spam filtering
- Made INI file parsing routine much more robust
- Returns to Setup screen if there is no mail
- Instructions can be accessed from Setup screen
- Better handling of login errors
- Attachments can be saved temporarily, (deleted after viewing)
- Other minor changes made

Version 1.2 (November 1999)
- You can use Delete key on keyboard to delete e-mails
- Much more help available within the program
- Cosmetic changes
- Rebuilt with updated libraries (even more stable)
- You can now exit to "Setup" screen from under the File menu
- "Keep-alive" is now turned on by default
- Text background is white by default; much easier to read
- When saving e-mails to text files, no default extension is added
- Many other minor changes made

Version 1.1 (August 1999)
- Click columns to sort (ascending or descending)
  e.g. upon entering, click Date/Time to sort newest to oldest
- Improved date parsing
- Converts dates such as 'Dec 99' and 'Jan 00' to 4-digit years
- No longer crashes when encountering "dangerously-long" header lines
- Can now deal with a read-only INI file (e.g. shared over a network)
- View window won't get 'stuck' if server disconnects
- Maximum messages increased from 1,000 to 10,000

Version 1.0 (July 1999)
- Does final refresh of view window after loading message
