joinwav 1.0 - Join many PCM WAV files into single audio file
Copyright (C) 2004 Jem E. Berkes [ www.sysdesign.ca ]

Usage: joinwav 01.wav 02.wav ... [output.wav]
        If the last file does not exist, it will become the output.
        Otherwise, the default name 'joined.wav' will be created.

  Input WAV files must have the same format (channels, bits, etc.)
  and output file will match. This program can merge most PCM WAV
  files (e.g. tracks ripped from audio CDs) but will not handle
  files with compression, errors, or unusual parameters.

                Freeware from www.pc-tools.net

========
Warranty
========

None. There is no warranty. Use at your own risk!

========
Examples
========

joinwav 01.wav 02.wav 03.wav 04.wav
	This combines 01.wav, 02.wav, 03.wav, 04.wav into "joined.wav"

joinwav 01.wav 02.wav 03.wav 04.wav combined.wav
	This combines 01.wav, 02.wav, 03.wav, 04.wav into "combined.wav"

=====
UNIX?
=====

If you are looking for a version that runs under Linux, FreeBSD etc. please
contact the author. This software compiles for several platforms.
