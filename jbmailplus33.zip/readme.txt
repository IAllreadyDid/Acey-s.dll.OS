JBMail 3.3 beta3a
www.berkes.ca
Copyright (C) 2005 Jem Berkes <jem@berkes.ca>


THIS IS EXPERIMENTAL SOFTWARE - USE AT YOUR OWN RISK - NO SUPPORT AVAILABLE

A FREE LICENSE FOR JBMAIL PLUS IS GRANTED TO YOU. YOU MAY USE JBMAIL PLUS FOR
EITHER PERSONAL OR BUSINESS USE, INCLUDING IN A CORPORATE MULTI-USER SETTING.
THIS SOFTWARE HAS NOT BEEN FULLY TESTED. THERE IS NO WARRANTY OR SUPPORT.


	Here is the recommended way to 'upgrade' to this new version:
	
	1. Create a new directory for this beta JBMail installation. Unzip the
	new files into the fresh directory.  Here is what the files do:
	
		jbmail.exe	Main program
		libeay32.dll	OpenSSL library for SSL/TLS encryption
		ssleay32.dll	OpenSSL library for SSL/TLS encryption
		jbmail.md5	Checksum file

	2. (Optional) Copy old JBMAIL.INI and JBMAIL.DAT files to the new location.
	This copies all settings, and leaves the original installation unmodified.
	
	3. Run jbmail.exe, and click Help menu, then About.  If the newest version
	and latest SSL libraries have loaded, you should see the following:
		JBMail Plus 3.3 beta3a
		Copyright (C) 1999-2005, Jem Berkes
		SSL support: OpenSSL 1.0.1e 11 Feb 2013

	If you encounter any problems, you can try:
	a) Deleting JBMAIL.INI and JBMAIL.DAT to reset all settings to default
	b) Deleting the two DLL files, in case they are the cause of instability
		You can try using the DLL files from your original installation.
		If you do this, you will also have to delete jbmail.md5 otherwise
		JBMail will detect that its files have been tampered with.

	
	
The following changes are in this beta version:

* JBMail now supports PGP encryption and signatures via the external GnuPG
software. This is free from www.gnupg.org and a good guide is
[ http://www.gnupg.org/gph/en/manual.html ]. GnuPG is compatible with PGP and other
OpenPGP compliant software. Once you configure all your keys etc such that you can
use it normally from the command line, you can enable GnuPG support in JBMail from
the Global tab. The Composer will then allow you to sign/encrypt emails, using the
recipients' addresses to automatically select the destination keys and optionally
encrypting back to yourself as well. Similarly, the Viewer will allow you to GPG/PGP
decrypt and verify signatures. All diagnostic information straight from GnuPG is
shown within a status window. GnuPG handles all passphrases and keys, so JBMail does
not introduce any new key/password risks.

* Improved compatibility with Wine, to run JBMail under Linux. The Composer does
not work under the current Wine release 20050211, however the Wine bug responsible
has now been fixed. JBMail works perfectly with Wine from CVS 2005-02-21. So this
means that we can expect full JBMail/Wine compatibility at next Wine release!

* Fixed viewing of plain text messages arriving in base64 encoded format. Outlook
and some other mailers send base64 encoded plain text bodies.

* In the Composer, under the Message menu there is now an autocomplete option.
You can enable or disable the feature by checking the option in the Message menu.
If you have addresses in the address books, this will automatically paste in a
matching address as soon as you have entered enough letters to identify a unique
address by substring. For example just entering "jem" should be enough to locate
Jem Berkes. It won't work if there is more than one entry that contains the same
substring (ambiguous). After an address is pasted, you can continue entering more
addresses by separating your new entry with a comma.

* JBMail now supports mailto: URL handling. This means that a web browser can now
launch JBMail and automatically open the Composer. Under the Global tab, you will
need to "Set mailto: handler" as Administrator. This will alter the registry.

* Similarly, under the Global tab you can enable the .JBM file association. This
lets you open up archived raw email format messages within the JBMail viewer. The
Inbox's File | Save functions write .JBM files by default. This is a good long
term archival method, since emails are saved to disk folders.

* The address book manager now lets you search all books for a substring

* Mailman can now check for active dialup (RAS) connections first, if the option
is enabled under the Global settings tab.


FULL CHANGELOG:
- Added Global option to "Check for RAS connection first" before Mailman checks POP3
- Fixed saving of plain text attachments
- Fixed bug where occasional very large downloads over SSL would fail at end
- Added Search function to Address Book manager (locate matching name/address)
- Replied message flag now cleared if you cancel a reply
- Improved Wine compatibility
- Fixed viewing of text bodies in base64 encoded format
- Added autocomplete for Composer under menu Message | Autocomplete address
- The mailto: handler and .jbm file association can now be set from the Global tab
- Added mailto: hyperlink support with new /TO command line switch
- Added "Strip email addresses" menu option in Composer, for improved recipient privacy
- Added GnuPG support (allows sign, encrypt, decrypt of GPG/PGP messages)
- A 'Done' message box appears at the end of a message save operation
